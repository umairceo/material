<?PHP
    $item = array(
            "Name" => "Beuty Kit",
            "Image" => "beutyKit.png",
            "Price" => 14.5,
            "Detail" => "Harmfull for ladies and girl"
    );
    $items_data[] = $item;

    $item = array(
        "Name" => "Sofa",
        "Image" => "homedecor.png",
        "Price" => 2500,
        "Detail" => "Dont Sleep only stand until tired");
    $items_data[] = $item;
?>