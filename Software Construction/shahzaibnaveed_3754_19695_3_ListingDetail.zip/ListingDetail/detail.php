<?PHP

	include("data.php");
	
	$item = $items_data[$_GET["id"]];
?>

	<p>Item:<?PHP echo $item["Name"]; ?></p>
    <p><img src="assets/images/<?PHP echo $item["Image"]; ?>" /></p>
    <p>Price:<?PHP echo $item["Price"]; ?></p>
        <p><?PHP echo $item["Detail"]; ?></p>
